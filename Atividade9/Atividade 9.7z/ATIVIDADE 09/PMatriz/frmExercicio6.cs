﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatriz
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            
            string auxiliar="", auxiliar2="";
            int[] vetor = new int[20];
            
                for (var i = 0; i < 4; i++) //Meu RA: 0030482213044
                {
                    auxiliar = Interaction.InputBox("Digite o nome: " + (i + 1), "Entrada de dados");
                if (int.TryParse(auxiliar, out vetor[i])) //se não conseguir converter então
                {
                    MessageBox.Show("Valor Inválido! ");
                    i--; //volta uma posição porque deu valor invalido
                }
                else
                {
                    auxiliar2 = auxiliar.Replace(" ", "");
                    int tamanho = auxiliar2.Length;
                    lstBoxNomes.Items.Add("O nome " + auxiliar + " possui " + tamanho + " caracteres;");
                }
        }

    }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBoxNomes.Items.Clear();
        }

        private void lblTituloEx6_Click(object sender, EventArgs e)
        {

        }
    }
}
