﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030481913006
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Projeto feito por: Cristian Eduardo Justi \n" +
                "RA: 0030481913006 \n" + "Fatec Sorocaba - Linguagem de Programação II", "Sobre");
        }
    }
}
