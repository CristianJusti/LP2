﻿
namespace PMenu
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdeR = new System.Windows.Forms.Button();
            this.btnQtdeEspaco = new System.Windows.Forms.Button();
            this.btnQtdeSeq = new System.Windows.Forms.Button();
            this.RCHtxtBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdeR
            // 
            this.btnQtdeR.Location = new System.Drawing.Point(326, 256);
            this.btnQtdeR.Name = "btnQtdeR";
            this.btnQtdeR.Size = new System.Drawing.Size(143, 86);
            this.btnQtdeR.TabIndex = 4;
            this.btnQtdeR.Text = "Quantidade de letra \'R\' na frase";
            this.btnQtdeR.UseVisualStyleBackColor = true;
            this.btnQtdeR.Click += new System.EventHandler(this.btnQtdeR_Click);
            // 
            // btnQtdeEspaco
            // 
            this.btnQtdeEspaco.Location = new System.Drawing.Point(121, 256);
            this.btnQtdeEspaco.Name = "btnQtdeEspaco";
            this.btnQtdeEspaco.Size = new System.Drawing.Size(143, 86);
            this.btnQtdeEspaco.TabIndex = 5;
            this.btnQtdeEspaco.Text = "Quantidade de espaços na frase";
            this.btnQtdeEspaco.UseVisualStyleBackColor = true;
            this.btnQtdeEspaco.Click += new System.EventHandler(this.btnQtdeEspaco_Click);
            // 
            // btnQtdeSeq
            // 
            this.btnQtdeSeq.Location = new System.Drawing.Point(531, 256);
            this.btnQtdeSeq.Name = "btnQtdeSeq";
            this.btnQtdeSeq.Size = new System.Drawing.Size(143, 86);
            this.btnQtdeSeq.TabIndex = 3;
            this.btnQtdeSeq.Text = "Quantidade de letras sequnciais";
            this.btnQtdeSeq.UseVisualStyleBackColor = true;
            this.btnQtdeSeq.Click += new System.EventHandler(this.btnQtdeSeq_Click);
            // 
            // RCHtxtBox
            // 
            this.RCHtxtBox.Location = new System.Drawing.Point(81, 36);
            this.RCHtxtBox.Name = "RCHtxtBox";
            this.RCHtxtBox.Size = new System.Drawing.Size(641, 166);
            this.RCHtxtBox.TabIndex = 2;
            this.RCHtxtBox.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnQtdeSeq);
            this.Controls.Add(this.btnQtdeR);
            this.Controls.Add(this.btnQtdeEspaco);
            this.Controls.Add(this.RCHtxtBox);
            this.Name = "frmExercicio1";
            this.Text = "Exercicio 1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnQtdeR;
        private System.Windows.Forms.Button btnQtdeEspaco;
        private System.Windows.Forms.Button btnQtdeSeq;
        private System.Windows.Forms.RichTextBox RCHtxtBox;
    }
}