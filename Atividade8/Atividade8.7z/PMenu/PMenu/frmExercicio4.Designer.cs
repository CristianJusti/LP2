﻿
namespace PMenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nome = new System.Windows.Forms.Label();
            this.lbl_cargo = new System.Windows.Forms.Label();
            this.lbl_matricula = new System.Windows.Forms.Label();
            this.lbl_producao = new System.Windows.Forms.Label();
            this.lbl_salario = new System.Windows.Forms.Label();
            this.lbl_gratificacao = new System.Windows.Forms.Label();
            this.txtBoxNome = new System.Windows.Forms.TextBox();
            this.txtBoxCargo = new System.Windows.Forms.TextBox();
            this.txtBoxMatricula = new System.Windows.Forms.TextBox();
            this.txtBoxProd = new System.Windows.Forms.TextBox();
            this.txtBoxSalario = new System.Windows.Forms.TextBox();
            this.btn_calcular = new System.Windows.Forms.Button();
            this.checkBoxGrat = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lbl_nome
            // 
            this.lbl_nome.AutoSize = true;
            this.lbl_nome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_nome.Location = new System.Drawing.Point(54, 26);
            this.lbl_nome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_nome.Name = "lbl_nome";
            this.lbl_nome.Size = new System.Drawing.Size(53, 21);
            this.lbl_nome.TabIndex = 0;
            this.lbl_nome.Text = "Nome";
            // 
            // lbl_cargo
            // 
            this.lbl_cargo.AutoSize = true;
            this.lbl_cargo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_cargo.Location = new System.Drawing.Point(54, 56);
            this.lbl_cargo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_cargo.Name = "lbl_cargo";
            this.lbl_cargo.Size = new System.Drawing.Size(52, 21);
            this.lbl_cargo.TabIndex = 0;
            this.lbl_cargo.Text = "Cargo";
            // 
            // lbl_matricula
            // 
            this.lbl_matricula.AutoSize = true;
            this.lbl_matricula.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_matricula.Location = new System.Drawing.Point(54, 87);
            this.lbl_matricula.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_matricula.Name = "lbl_matricula";
            this.lbl_matricula.Size = new System.Drawing.Size(75, 21);
            this.lbl_matricula.TabIndex = 0;
            this.lbl_matricula.Text = "Matrícula";
            // 
            // lbl_producao
            // 
            this.lbl_producao.AutoSize = true;
            this.lbl_producao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_producao.Location = new System.Drawing.Point(54, 118);
            this.lbl_producao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_producao.Name = "lbl_producao";
            this.lbl_producao.Size = new System.Drawing.Size(76, 21);
            this.lbl_producao.TabIndex = 0;
            this.lbl_producao.Text = "Produção";
            // 
            // lbl_salario
            // 
            this.lbl_salario.AutoSize = true;
            this.lbl_salario.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_salario.Location = new System.Drawing.Point(54, 149);
            this.lbl_salario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_salario.Name = "lbl_salario";
            this.lbl_salario.Size = new System.Drawing.Size(58, 21);
            this.lbl_salario.TabIndex = 0;
            this.lbl_salario.Text = "Salário";
            // 
            // lbl_gratificacao
            // 
            this.lbl_gratificacao.AutoSize = true;
            this.lbl_gratificacao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbl_gratificacao.Location = new System.Drawing.Point(54, 181);
            this.lbl_gratificacao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_gratificacao.Name = "lbl_gratificacao";
            this.lbl_gratificacao.Size = new System.Drawing.Size(92, 21);
            this.lbl_gratificacao.TabIndex = 0;
            this.lbl_gratificacao.Text = "Gratificação";
            // 
            // txtBoxNome
            // 
            this.txtBoxNome.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBoxNome.Location = new System.Drawing.Point(172, 26);
            this.txtBoxNome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxNome.Name = "txtBoxNome";
            this.txtBoxNome.Size = new System.Drawing.Size(180, 25);
            this.txtBoxNome.TabIndex = 1;
            // 
            // txtBoxCargo
            // 
            this.txtBoxCargo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBoxCargo.Location = new System.Drawing.Point(172, 56);
            this.txtBoxCargo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxCargo.Name = "txtBoxCargo";
            this.txtBoxCargo.Size = new System.Drawing.Size(180, 25);
            this.txtBoxCargo.TabIndex = 1;
            // 
            // txtBoxMatricula
            // 
            this.txtBoxMatricula.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBoxMatricula.Location = new System.Drawing.Point(172, 87);
            this.txtBoxMatricula.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxMatricula.Name = "txtBoxMatricula";
            this.txtBoxMatricula.Size = new System.Drawing.Size(180, 25);
            this.txtBoxMatricula.TabIndex = 1;
            // 
            // txtBoxProd
            // 
            this.txtBoxProd.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBoxProd.Location = new System.Drawing.Point(172, 118);
            this.txtBoxProd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxProd.Name = "txtBoxProd";
            this.txtBoxProd.Size = new System.Drawing.Size(180, 25);
            this.txtBoxProd.TabIndex = 1;
            // 
            // txtBoxSalario
            // 
            this.txtBoxSalario.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBoxSalario.Location = new System.Drawing.Point(172, 149);
            this.txtBoxSalario.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBoxSalario.Name = "txtBoxSalario";
            this.txtBoxSalario.Size = new System.Drawing.Size(180, 25);
            this.txtBoxSalario.TabIndex = 1;
            // 
            // btn_calcular
            // 
            this.btn_calcular.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_calcular.Location = new System.Drawing.Point(402, 87);
            this.btn_calcular.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_calcular.Name = "btn_calcular";
            this.btn_calcular.Size = new System.Drawing.Size(99, 48);
            this.btn_calcular.TabIndex = 2;
            this.btn_calcular.Text = "Calcular";
            this.btn_calcular.UseVisualStyleBackColor = true;
            this.btn_calcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBoxGrat
            // 
            this.checkBoxGrat.AutoSize = true;
            this.checkBoxGrat.Location = new System.Drawing.Point(178, 186);
            this.checkBoxGrat.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.checkBoxGrat.Name = "checkBoxGrat";
            this.checkBoxGrat.Size = new System.Drawing.Size(15, 14);
            this.checkBoxGrat.TabIndex = 3;
            this.checkBoxGrat.UseVisualStyleBackColor = true;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 270);
            this.Controls.Add(this.checkBoxGrat);
            this.Controls.Add(this.btn_calcular);
            this.Controls.Add(this.txtBoxSalario);
            this.Controls.Add(this.txtBoxProd);
            this.Controls.Add(this.txtBoxMatricula);
            this.Controls.Add(this.txtBoxCargo);
            this.Controls.Add(this.txtBoxNome);
            this.Controls.Add(this.lbl_gratificacao);
            this.Controls.Add(this.lbl_salario);
            this.Controls.Add(this.lbl_producao);
            this.Controls.Add(this.lbl_matricula);
            this.Controls.Add(this.lbl_cargo);
            this.Controls.Add(this.lbl_nome);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio4";
            this.Text = "Exercicio 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_nome;
        private System.Windows.Forms.Label lbl_cargo;
        private System.Windows.Forms.Label lbl_matricula;
        private System.Windows.Forms.Label lbl_producao;
        private System.Windows.Forms.Label lbl_salario;
        private System.Windows.Forms.Label lbl_gratificacao;
        private System.Windows.Forms.TextBox txtBoxNome;
        private System.Windows.Forms.TextBox txtBoxCargo;
        private System.Windows.Forms.TextBox txtBoxMatricula;
        private System.Windows.Forms.TextBox txtBoxProd;
        private System.Windows.Forms.TextBox txtBoxSalario;
        private System.Windows.Forms.Button btn_calcular;
        private System.Windows.Forms.CheckBox checkBoxGrat;
    }
}