﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string s;
            string s2;
            int tamanho;

            s = txtBox.Text;
            tamanho = s.Length;

            if (tamanho <= 50)
            {
                s = s.Replace(" ", "");
                s = s.ToLower();
                s2 = s;

                char[] arr = s.ToCharArray();
                Array.Reverse(arr);
                s = "";
                foreach (char c in arr)
                {
                    s = s + c.ToString();
                }

                if (String.Compare(s2, s, true) == 0)
                {
                    MessageBox.Show("A palavra é um palíndromo");
                }
                else
                {
                    MessageBox.Show("A palavra não é um palíndromo");
                }
            }
            else
            {
                MessageBox.Show("A palavra não deve exceder o limite de 50 caracteres ");
            }
        }
    }
}
