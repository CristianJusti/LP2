﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double H = 0;
            double N;
            double i;

            if ((txtBox.Text == ""))
            {
                MessageBox.Show("Insira um número");
            }
            else
            {
                if ((double.TryParse(txtBox.Text, out N)))
                {
                    if (N > 0)
                    {
                        for (i = 1; i < N + 1; i++)
                        {
                            H = H + 1 / i;

                        }
                        MessageBox.Show("Resultado :" + H.ToString());
                    }
                    else
                        MessageBox.Show("Valor inválido");
                }
            }
        }

    }
}