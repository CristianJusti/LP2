﻿
namespace PMenu
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBox = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lbl_numeroH = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtBox
            // 
            this.txtBox.Location = new System.Drawing.Point(56, 93);
            this.txtBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBox.Name = "txtBox";
            this.txtBox.Size = new System.Drawing.Size(450, 23);
            this.txtBox.TabIndex = 12;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(231, 153);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(100, 52);
            this.btnVerificar.TabIndex = 11;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // lbl_numeroH
            // 
            this.lbl_numeroH.AutoSize = true;
            this.lbl_numeroH.Location = new System.Drawing.Point(231, 44);
            this.lbl_numeroH.Name = "lbl_numeroH";
            this.lbl_numeroH.Size = new System.Drawing.Size(97, 15);
            this.lbl_numeroH.TabIndex = 13;
            this.lbl_numeroH.Text = "Gerar Número H:";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 270);
            this.Controls.Add(this.lbl_numeroH);
            this.Controls.Add(this.txtBox);
            this.Controls.Add(this.btnVerificar);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio2";
            this.Text = "Exercicio 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBox;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lbl_numeroH;
    }
}