﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double salario;
            double producao;
            double B = 0;
            double C = 0;
            double D = 0;
            double salarioBruto;



            if ((double.TryParse(txtBoxSalario.Text, out salario)) &&
                (double.TryParse(txtBoxProd.Text, out producao)))
            {
                if (txtBoxCargo.Text == "" || txtBoxMatricula.Text == "" || txtBoxNome.Text == "" || txtBoxProd.Text == "" || txtBoxSalario.Text == "" || salario < 0
                    || producao < 0)
                {
                    MessageBox.Show("Algum valor está em branco, por favor verifique!");
                }
                else
                {
                    if (producao >= 100)
                    {
                        B = 1;
                    }
                    if (producao >= 120)
                    {
                        C = 1;
                    }
                    if (producao >= 150)
                    {
                        D = 1;
                    }

                    if (checkBoxGrat.Checked && salario > 7000 && producao >= 150)
                    {
                        salarioBruto = salario + (salario * ((0.05 * B) + (0.1 * C) + (0.1 * D)));
                        MessageBox.Show("O salario bruto é: " + salarioBruto.ToString());
                    }
                    else if (!checkBoxGrat.Checked && salario <= 7000)
                    {
                        salarioBruto = salario + (salario * ((0.05 * B) + (0.1 * C) + (0.1 * D)));
                        MessageBox.Show("O salario bruto é: " + salarioBruto.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Algo deu errado, por favor verifique os dados");
                    }
                }

            }
            else
            {
                MessageBox.Show("Valores invalidos");
            }
        }
    }
}