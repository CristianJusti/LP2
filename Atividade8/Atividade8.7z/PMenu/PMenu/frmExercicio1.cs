﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnQtdeEspaco_Click(object sender, EventArgs e)
        {
            {

                int i = 0;
                int caracBrancos = 0;

                char[] pPalavra = RCHtxtBox.Text.ToCharArray();


                for (i = 0; i < RCHtxtBox.Text.Length; i++)
                {
                    if (char.IsWhiteSpace(pPalavra[i]))
                    {
                        caracBrancos++;

                    }

                }

                MessageBox.Show("A quantidade de espaços em brancos nessa frase é: "
                + caracBrancos.ToString());
            }
        }

        private void btnQtdeR_Click(object sender, EventArgs e)
        {
            {
                int caracR = 0;

                char[] pCaracter = RCHtxtBox.Text.ToCharArray();

                foreach (char r in pCaracter)
                {
                    if (r == 'r')
                    {
                        caracR++;
                    }

                }
                MessageBox.Show("A quantidade de letras R nessa frase é: " + caracR.ToString());

            }
        }

        private void btnQtdeSeq_Click(object sender, EventArgs e)
        {
            {
                int caracRepetido = 0;
                int i;

                for (i = 1; i < RCHtxtBox.Text.Length; i++)

                {
                    if (RCHtxtBox.Text[i] == RCHtxtBox.Text[i - 1])
                    {
                        caracRepetido++;
                    }

                }

                MessageBox.Show("A quantidade de letras repetidas nessa frase é: "
                + caracRepetido.ToString());
            }


        }
    }
}