﻿using Microsoft.VisualBasic;
using System;
using System.Linq;
using System.Windows.Forms;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            int tamanho = 8;
            char[,] resposta = new char[tamanho, 10];
            char[] gabarito = new char[] { 'A', 'B', 'C', 'A', 'E', 'C', 'D', 'A', 'E', 'E' };
            char[] opcoes = new char[] { 'A', 'B', 'C', 'D', 'E' };

            for (int i = 0; i < resposta.GetLength(0); i++)
            {
                for (int j = 0; j < resposta.GetLength(1); j++)
                {
                    string alternativa = Interaction.InputBox($"Aluno {i + 1}, digite sua resposta para a questão {j + 1}:", "ENTRADA");
                    if (!char.TryParse(alternativa, out char alternativaChar) || int.TryParse(alternativa, out int result))
                    {
                        MessageBox.Show("Digite apenas caracteres alfabéticos.");
                        j--;
                    }
                    else if(!opcoes.Contains(char.ToUpper(alternativaChar)))
                    {
                        MessageBox.Show("Escolha entre as opções A, B, C, D ou E");
                        j--;
                    }
                    else
                    {
                        string resultado = char.ToUpper(alternativaChar) == gabarito[j] ? $"O aluno {i + 1}, acertou a questão {j + 1}. Era {gabarito[j]} escolheu {char.ToUpper(alternativaChar)}"
                            : $"O aluno {i + 1}, errou a questão {j + 1}. Era {gabarito[j]} escolheu {char.ToUpper(alternativaChar)}";
                        lstBox.Items.Add(resultado);
                    }
                }

            }

        }
    }
}
