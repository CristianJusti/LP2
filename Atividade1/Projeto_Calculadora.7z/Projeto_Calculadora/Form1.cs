﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Calculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Num1.Text, out numero1) &&
                double.TryParse(Num2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                Num3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Num1.Text, out numero1) &&
                double.TryParse(Num2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                Num3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnMulti_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Num1.Text, out numero1) &&
                double.TryParse(Num2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                Num3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Números inválidos!");
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (double.TryParse(Num1.Text, out numero1) &&
                double.TryParse(Num2.Text, out numero2))
            {
                if (numero2 == 0)
                    MessageBox.Show("Não pode dividir por zero!");
                else
                {
                    resultado = numero1 / numero2;
                    Num3.Text = resultado.ToString();
                }
            }
        }
        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            Num1.Clear();
            Num2.Clear();
            Num3.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
