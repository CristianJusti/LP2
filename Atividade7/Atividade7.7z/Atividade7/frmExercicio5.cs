﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = " ";
            txtNum2.Text = " ";
        }

        private void btnGerarNum_Click(object sender, EventArgs e)
        {
            int num1, num2;


            //verificar se é int
            if (!int.TryParse(txtNum1.Text, out num1) || !int.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Numero Inválido!");
            }
            else
            {
                if (num2 < num1)
                {
                    txtNum1.Text = "";
                    txtNum2.Text = "";
                    MessageBox.Show("O  segundo número precisa ser maior do o primeiro!");
                }
                else
                {

                    Random randNum = new Random();
                        listaResultado.Items.Add(randNum.Next(num1, num2).ToString());
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void listaResultado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
