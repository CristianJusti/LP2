﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {
            int  tamanho = rhcTexto.Text.Length, contador =0;
           string texto = rhcTexto.Text;


            for (int i = 0; i < tamanho; i++)
            {
                if (char.IsNumber(texto[i]))
                {
                    contador ++;
                }
            }
            MessageBox.Show("Há " + contador + " número no texto");
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            string aux = rhcTexto.Text;
            int contador = 0;

            foreach (char caracter in aux)
            {
                if (char.IsLetter(caracter))
                {
                    contador++;
                }
            }
            MessageBox.Show("Há " + contador + " caracteres alfabéticos no texto");
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int tamanho = rhcTexto.Text.Length, i = 0, posicao = 0;
            string texto = rhcTexto.Text;

            while(i < tamanho) {
                    if (!char.IsWhiteSpace(texto[i]))
                    {
                        i++;
                    }
                    else
                    {
                        posicao = i + 1;
                    break;
            }
            }
            MessageBox.Show("O espaço branco está na posição " + posicao + " do texto");
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }
    }
}
