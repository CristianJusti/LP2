﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnNumerico;
            this.rhcTexto = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnAlfabetico = new System.Windows.Forms.Button();
            btnNumerico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNumerico
            // 
            btnNumerico.BackColor = System.Drawing.Color.Navy;
            btnNumerico.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            btnNumerico.ForeColor = System.Drawing.Color.White;
            btnNumerico.Location = new System.Drawing.Point(35, 210);
            btnNumerico.Name = "btnNumerico";
            btnNumerico.Size = new System.Drawing.Size(125, 65);
            btnNumerico.TabIndex = 1;
            btnNumerico.Text = "Numéricos";
            btnNumerico.UseVisualStyleBackColor = false;
            btnNumerico.Click += new System.EventHandler(this.btnNumerico_Click);
            // 
            // rhcTexto
            // 
            this.rhcTexto.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rhcTexto.Location = new System.Drawing.Point(55, 27);
            this.rhcTexto.Name = "rhcTexto";
            this.rhcTexto.Size = new System.Drawing.Size(343, 148);
            this.rhcTexto.TabIndex = 0;
            this.rhcTexto.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.BackColor = System.Drawing.Color.Navy;
            this.btnEspacoBranco.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspacoBranco.ForeColor = System.Drawing.Color.White;
            this.btnEspacoBranco.Location = new System.Drawing.Point(166, 210);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(125, 65);
            this.btnEspacoBranco.TabIndex = 2;
            this.btnEspacoBranco.Text = "Posição do Primeiro Espaço em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = false;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnAlfabetico
            // 
            this.btnAlfabetico.BackColor = System.Drawing.Color.Navy;
            this.btnAlfabetico.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlfabetico.ForeColor = System.Drawing.Color.White;
            this.btnAlfabetico.Location = new System.Drawing.Point(297, 210);
            this.btnAlfabetico.Name = "btnAlfabetico";
            this.btnAlfabetico.Size = new System.Drawing.Size(125, 65);
            this.btnAlfabetico.TabIndex = 3;
            this.btnAlfabetico.Text = "Alfabéticos";
            this.btnAlfabetico.UseVisualStyleBackColor = false;
            this.btnAlfabetico.Click += new System.EventHandler(this.btnAlfabetico_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(450, 321);
            this.Controls.Add(this.btnAlfabetico);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(btnNumerico);
            this.Controls.Add(this.rhcTexto);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rhcTexto;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnAlfabetico;
    }
}